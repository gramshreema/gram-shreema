ग्राम श्रीमा — Firebase OTP सुरक्षित Android प्रोजेक्ट

Firebase config: आपके द्वारा भेजी गई google-services.json को app/google-services.json में रखा गया है।

पहले Firebase Console में:
1. Authentication → Sign-in method → Phone को Enable करें।
2. Firestore Database बनाएं।
3. Storage Enable करें।
4. Android app में SHA-1/SHA-256 fingerprints जोड़ें (Phone Auth के लिए)।
5. firestore.rules और storage.rules लागू करें।
6. Admin बनाने के लिए Firestore में collection `admins` और document का नाम उस Admin user का Firebase UID रखें।
   उदाहरण: admins/USER_UID  (field role = "admin")
7. Android Studio में प्रोजेक्ट खोलें → Gradle Sync → Build APK.

महत्वपूर्ण: OTP/SMS के लिए Firebase की quota/billing/verification requirements लागू हो सकती हैं।


नया: .github/workflows/build-apk.yml जो GitHub Actions से APK बनाता है।
Play Store के लिए target/compile SDK 36 रखा गया है।
