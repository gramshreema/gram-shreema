package com.shreema.gramshikayat;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.*;

import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {

    FirebaseAuth auth;
    EditText phone, otp;
    Button sendOtp, verifyOtp;
    TextView status;
    String verificationId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        auth = FirebaseAuth.getInstance();

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(30, 30, 30, 30);

        TextView title = new TextView(this);
        title.setText("Gram Shreema - Mobile OTP Login");
        title.setTextSize(24);
        layout.addView(title);

        phone = new EditText(this);
        phone.setHint("Mobile number with +91");
        phone.setInputType(2);
        layout.addView(phone);

        sendOtp = new Button(this);
        sendOtp.setText("Send OTP");
        layout.addView(sendOtp);

        otp = new EditText(this);
        otp.setHint("Enter OTP");
        otp.setInputType(2);
        layout.addView(otp);

        verifyOtp = new Button(this);
        verifyOtp.setText("Verify OTP");
        layout.addView(verifyOtp);

        status = new TextView(this);
        status.setTextSize(16);
        layout.addView(status);

        setContentView(layout);

        sendOtp.setOnClickListener(v -> sendOTP());

        verifyOtp.setOnClickListener(v -> verifyOTP());
    }

    void sendOTP() {
        String number = phone.getText().toString().trim();

        if (number.length() < 10) {
            status.setText("Enter a valid mobile number");
            return;
        }

        if (!number.startsWith("+91")) {
            number = "+91" + number;
        }

        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(auth)
                        .setPhoneNumber(number)
                        .setTimeout(60L, TimeUnit.SECONDS)
                        .setActivity(this)
                        .setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

                            @Override
                            public void onVerificationCompleted(
                                    PhoneAuthCredential credential) {
                                signIn(credential);
                            }

                            @Override
                            public void onVerificationFailed(FirebaseException e) {
                                status.setText(
                                        "OTP failed: " + e.getMessage()
                                );
                            }

                            @Override
                            public void onCodeSent(
                                    String id,
                                    PhoneAuthProvider.ForceResendingToken token) {
                                verificationId = id;
                                status.setText("OTP sent successfully");
                            }
                        })
                        .build();

        PhoneAuthProvider.verifyPhoneNumber(options);
    }

    void verifyOTP() {
        String code = otp.getText().toString().trim();

        if (verificationId == null) {
            status.setText("Please send OTP first");
            return;
        }

        if (code.length() != 6) {
            status.setText("Enter 6 digit OTP");
            return;
        }

        PhoneAuthCredential credential =
                PhoneAuthProvider.getCredential(verificationId, code);

        signIn(credential);
    }

    void signIn(PhoneAuthCredential credential) {
        auth.signInWithCredential(credential)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        status.setText("Login successful");
                    } else {
                        status.setText(
                                "Login failed: " +
                                task.getException().getMessage()
                        );
                    }
                });
    }
}